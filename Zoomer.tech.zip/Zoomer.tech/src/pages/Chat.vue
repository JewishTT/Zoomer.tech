<script>
export default {
  name: 'Chat'
}
</script>

<template>

</template>