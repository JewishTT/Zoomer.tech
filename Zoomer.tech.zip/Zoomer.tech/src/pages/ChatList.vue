<script lang="ts">

export default {
  name: 'ChatList'
}
</script>

<template>

</template>