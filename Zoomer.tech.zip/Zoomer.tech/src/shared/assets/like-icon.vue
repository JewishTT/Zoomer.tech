<script>
export default {
  name: "likeIcon"
}
</script>

<template>
  <div>
    <img src="../assets/like-icon.svg" alt="message icon" style="width:24px; height:24px;">
  </div>
</template>

<style>

</style>