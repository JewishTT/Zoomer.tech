<script>
export default {
  name: "userIcon"
}
</script>

<template>
  <div>
    <img src="../assets/user.svg" alt="message icon" style="width:24px; height:24px;">
  </div>
</template>

<style>

</style>