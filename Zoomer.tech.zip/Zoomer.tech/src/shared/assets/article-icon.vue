<script>
export default {
  name: "articleIcon"
}
</script>

<template>
  <div>
    <img src="../assets/article.svg" alt="message icon" style="width:24px; height:24px;">
  </div>
</template>

<style>

</style>