<script>
export default {
  name: "homeIcon"
}
</script>

<template>
  <div>
    <img src="../assets/home.svg" alt="message icon" style="width:24px; height:24px;">
  </div>
</template>

<style>

</style>