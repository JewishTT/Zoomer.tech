"use strict";
import express from 'express';
import DB from './db.js';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import bodyParser from 'body-parser';
import multer from 'multer';
import path from 'path';

const db = new DB("sqlitedb");
const app = express();
const router = express.Router();
router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());

const allowCrossDomain = (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', '*');
    res.header('Access-Control-Allow-Headers', '*');
    next();
};

const secret = "supersecret";

app.use(allowCrossDomain);

router.post('/register', (req, res) => {
    db.insert([
        req.body.name,
        req.body.email,
        bcrypt.hashSync(req.body.password, 8)
    ], (err) => {
        if (err) return res.status(500).send("There was a problem registering the user.");

        db.selectByEmail(req.body.email, (err, user) => {
            if (err) return res.status(500).send("There was a problem getting user");

            const token = jwt.sign(
                { id: user.id },
                secret,
                { expiresIn: 86400 }
            );

            res.status(200).send({
                auth: true,
                token: token,
                user: user
            });
        });
    });
});

router.post('/register-admin', (req, res) => {
    db.insertAdmin([
        req.body.name,
        req.body.email,
        bcrypt.hashSync(req.body.password, 8),
        1
    ], (err) => {
        if (err) return res.status(500).send("There was a problem registering the user.");

        db.selectByEmail(req.body.email, (err, user) => {
            if (err) return res.status(500).send("There was a problem getting user");

            const token = jwt.sign(
                { id: user.id },
                secret,
                { expiresIn: 86400 }
            );

            res.status(200).send({
                auth: true,
                token: token,
                user: user
            });
        });
    });
});

router.post('/login', (req, res) => {
    db.selectByEmail(req.body.email, (err, user) => {
        if (err) return res.status(500).send('Error on the server.');
        if (!user) return res.status(404).send('No user found.');

        const passwordIsValid = bcrypt.compareSync(req.body.password, user.user_pass);
        if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });

        const token = jwt.sign(
            { id: user.id },
            secret,
            { expiresIn: 86400 }
        );

        res.status(200).send({
            auth: true,
            token: token,
            user: user
        });
    });
});

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'src/shared/assets') // Путь к директории, где будут сохраняться файлы
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
});

const upload = multer({ storage: storage });

// Маршрут для загрузки фото
app.post('/загрузка', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('Ошибка: Не был получен файл.');
    }
    // Файл был успешно получен и сохранён
    res.send('Файл успешно загружен.');
});


app.use(router);

const port = process.env.PORT || 3000;
const server = app.listen(port, () => {
    console.log('Express server listening on port ' + port);
});
