<script lang="ts">

export interface ProfileCardProps {
  error?: string;
  isLoading?: boolean;
  readonly?: boolean;
  onChangeLastname?: (value?: string) => void;
  onChangeFirstname?: (value?: string) => void;
  onChangeCity?: (value?: string) => void;
  onChangeAge?: (value?: string) => void;
  onChangeUsername?: (value?: string) => void;
}


export default {
  name: 'ProfileCard',

}
</script>

<template>
  <Input
      value={data?.first}
      label={t('Имя')}
      onChange={onChangeFirstname}
      readonly={readonly}
      data-testid="ProfileCard.firstname"
  />
  <Input
      value={data?.lastname}
      label={t('Фамилия')}
      onChange={onChangeLastname}
      readonly={readonly}
      data-testid="ProfileCard.lastname"
  />
  <Input
      value={data?.age}
      label={t('Возраст')}
      onChange={onChangeAge}
      readonly={readonly}
  />
  <Input
      value={data?.city}
      label={t('Город')}
      onChange={onChangeCity}
      readonly={readonly}
  />
    <Input
        value={data?.username}
        label=('Имя пользователя')
    onChange={onChangeUsername}
    readonly={readonly}
    />

</template>

<style>

</style>