<script setup lang="ts">
import Sidebar from "../widgets/Sidebar/Sidebar.vue";
import Navbar from "../widgets/Navbar/Navbar.vue";
</script>

<template>
  <div>
    <router-view></router-view>
    <sidebar></sidebar>
    <navbar></navbar>
  </div>
</template>

<style scoped>

</style>
