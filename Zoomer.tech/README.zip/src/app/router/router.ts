import { createRouter, createWebHistory, RouteRecordRaw } from "vue-router";
import MainPage from "../../pages/MainPage.vue";
import ProfilePage from "../../pages/ProfilePage.vue";
import Chat from "../../pages/Chat.vue";
import HelpPage from "../../pages/HelpPage.vue";
import Settings from '../../pages/Settings.vue';
import ChatList from "../../pages/ChatList.vue";
import Articles from "../../pages/Articles.vue";
import SignIn from "../../features/authByUsername/AuthForm/Sign In.vue";
import SignUp from "../../features/authByUsername/AuthForm/Sign Up.vue";
import Admin from "../../entities/Admin/Admin.vue";


const routes: Array<RouteRecordRaw> = [
    {
        path: "/",
        name: "Home",
        component: MainPage,
    },
    {
        path: "/profile",
        name: "Profile",
        component: ProfilePage,
        meta: {
            requiresAuth: true
        }
    },
    {
        path: '/login',
        name: 'login',
        component: SignIn,
        meta: {
            guest: true
        }
    },
    {
        path: '/register',
        name: 'register',
        component: SignUp,
        meta: {
            guest: true
        }
    },
    {
        path: "/help",
        name: "HelpPage",
        component: HelpPage,
    },
    {
        path: "/chat",
        name: "Chat",
        component: Chat,
    },
    {
        path: "/settings",
        name: "Settings",
        component: Settings,
    },
    {
        path: "/chatlist",
        name: "ChatList",
        component: ChatList,
    },
    {
        path: "/articles",
        name: "Articles",
        component: Articles,
    },
    {
        path: '/admin',
        name: 'admin',
        component: Admin,
        meta: {
            requiresAuth: true,
            is_admin: true
        }
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

router.beforeEach((to, from, next) => {
    const jwt = localStorage.getItem('jwt');
    const profile = JSON.parse(localStorage.getItem('profile') || '{}');

    if (to.matched.some(record => record.meta.requiresAuth)) {
        if (!jwt) {
            next({ path: '/login', params: { nextUrl: to.fullPath } });
        } else {
            if (to.matched.some(record => record.meta.is_admin)) {
                if (profile.is_admin === 1) {
                    next();
                } else {
                    next({ name: 'profile' });
                }
            } else {
                next();
            }
        }
    } else if (to.matched.some(record => record.meta.guest)) {
        if (!jwt) {
            next();
        } else {
            next({ name: 'profile' });
        }
    } else {
        next();
    }
});

export default router;
