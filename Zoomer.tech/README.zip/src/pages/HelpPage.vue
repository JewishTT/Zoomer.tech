<script>
import Modal from "../shared/ui/Modal/Modal.vue";
import {ref} from "vue";
import Input from "../shared/ui/Input/Input.vue";
import LoginForm from "../features/authByUsername/AuthForm/Sign Up.vue";
import AuthForm from "../features/authByUsername/AuthForm/Sign Up.vue";
import SignIn from "../features/authByUsername/AuthForm/Sign In.vue";
import SignUp from "../features/authByUsername/AuthForm/Sign Up.vue";

export default {
  name: 'HelpPage',
  components: {
    SignUp,
    SignIn,
    AuthForm,
    Input,
    Modal,
  },
  setup () {
    const isModalVisible = ref(false)

    const showModal = () =>
    {
      isModalVisible.value = true;
    }

    const closeModal = () =>
    {
      isModalVisible.value = false;
    }

    return {
      isModalVisible,
      showModal,
      closeModal
    }
  },
};
</script>

<template>
  <div id="app">
    <button
        type="button"
        class="btn"
        @click="showModal"
    >
      Open Modal!
    </button>
<Input on-change="" value="" label=""></Input>
    <Modal
        v-show="isModalVisible"
        @close="closeModal"
    >

    </Modal>

  </div>
</template>