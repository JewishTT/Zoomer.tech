<script>
import Modal from "../shared/ui/Modal/Modal.vue";

export default {
  name: 'MainPage',
  components: {Modal}
}
</script>

<template>
  <div>
    Дом родной, где нет ни флага ни родины
  </div>
</template>

<style>

</style>