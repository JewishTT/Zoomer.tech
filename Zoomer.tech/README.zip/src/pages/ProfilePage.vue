<template>
  <div class="profile-container">
    <div class="profile-card">
      <img class="profile-image"  alt="Profile Image">
      <addPhoto/>
      <h1 v-if="!editMode">{{ profile.name }}</h1>
      <input v-else v-model="profile.name" type="text">
      <h1 v-if="!editMode">{{ profile.age + " Лет"}}</h1>
      <input v-else v-model="profile.age" type="number">
      <h1 v-if="!editMode">{{ profile.gender }}</h1>
      <input v-else v-model="profile.gender" type="text">
      <h1 v-if="!editMode">{{ profile.bio }}</h1>
      <input v-else v-model="profile.bio" type="text">
      <button @click="toggleEditMode">{{ editMode ? 'Сохранить' : 'Редактировать' }}</button>
    </div>
  </div>
</template>

<script setup>
import {ref, reactive, onMounted, watch, toRefs} from 'vue';
import AddPhoto from "../features/addPhoto/addPhoto.vue";

const editMode = ref(false);
const profile = reactive({
  name: 'Имя Фамилия',
  age: '18',
  gender: 'Муж/Жен',
  bio: 'Я дизайнер, из великого города Санкт-Петробурга',

});

onMounted(() => {
  if (localStorage.getItem('profile')) {
    Object.assign(profile, JSON.parse(localStorage.getItem('profile')));
  }
});

watch(profile, (newProfile) => {
  localStorage.setItem('profile', JSON.stringify(newProfile));
}, { deep: true });

const toggleEditMode = () => {
  editMode.value = !editMode.value;
  if (!editMode.value) {
    localStorage.setItem('profile', JSON.stringify(profile));
  }
};

const { name } = toRefs(profile);
</script>


<style scoped>
.profile-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.profile-card {
  border: 4px solid #e0e0e0; /* увеличенная рамка вокруг профиля */
  border-radius: 10px;
  padding: 20px;
  background-color: #ffffff; /* светлый фон карточки профиля */
  width: 600px;
  height: 450px;
  text-align: center;
}

.profile-image {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  margin-bottom: 20px;
}

.title {
  color: #757575;
  font-size: 18px;
}

h1, p {
  margin: 5px 0;
}
</style>
