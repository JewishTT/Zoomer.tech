<script>
export default {
  name: 'Navbar',
  props: {
    isLoggedIn: {
      type: Boolean,
      required: true
    }
  }
}
</script>

<template>
  <div class="navbar">

  </div>
</template>

<style>
.navbar {
  background-color: #333;
  color: white;
  font-size: 16px;
  padding: 20px;
  border-bottom: 1px solid #222;
  width: 100%;
  display: flex;
  align-items: center;
}
</style>