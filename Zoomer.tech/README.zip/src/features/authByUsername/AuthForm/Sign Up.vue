<script>
export default {
  props : ["nextUrl"],
  data(){
    return {
      name : "",
      email : "",
      password : "",
      password_confirmation : "",
      is_admin : null
    }
  },
  methods : {
    handleSubmit(e) {
      e.preventDefault()
      if (this.password === this.password_confirmation && this.password.length > 0)
      {
        let url = "http://localhost:3000/register"
        if(this.is_admin != null || this.is_admin == 1) url = "http://localhost:3000/register-admin"
        this.$http.post(url, {
          name: this.name,
          email: this.email,
          password: this.password,
          is_admin: this.is_admin
        })
            .then(response => {
              localStorage.setItem('user',JSON.stringify(response.data.user))
              localStorage.setItem('jwt',response.data.token)

              if (localStorage.getItem('jwt') != null){
                this.$emit('loggedIn')
                if(this.$route.params.nextUrl != null){
                  this.$router.push(this.$route.params.nextUrl)
                }
                else{
                  this.$router.push('/')
                }
              }
            })
            .catch(error => {
              console.error(error);
            });
      } else {
        this.password = ""
        this.passwordConfirm = ""

        return alert("Passwords do not match")
      }
    }
  }
}
</script>

<template>
  <div class="register-form">
    <h4>Register</h4>
    <form>
      <div class="form-group">
        <label for="name">Name</label>
        <input id="name" type="text" v-model="name" required autofocus>
      </div>
      <div class="form-group">
        <label for="email">E-Mail Address</label>
        <input id="email" type="email" v-model="email" required>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" type="password" v-model="password" required>
      </div>
      <div class="form-group">
        <label for="password-confirm">Confirm Password</label>
        <input id="password-confirm" type="password" v-model="password_confirmation" required>
      </div>
      <div class="form-group">
        <button type="submit" @click="handleSubmit">Sign Up</button>
      </div>
    </form>
  </div>
</template>

<style scoped>
.register-form {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f9f9f9;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  font-weight: bold;
}

input[type="text"],
input[type="email"],
input[type="password"],
select {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}

button {
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: #fff;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}
</style>
