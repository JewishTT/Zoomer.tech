<script>
import { ref } from 'vue';
import axios from 'axios';

export default {
  setup() {
    const email = ref("");
    const password = ref("");

    const handleSubmit = () => {
      if (password.value.length > 0) {
        axios.post('http://localhost:3000/login', {
          email: email.value,
          password: password.value
        })
            .then(response => {

              let is_admin = response.data.user.is_admin
              localStorage.setItem('user',JSON.stringify(response.data.user))
              localStorage.setItem('jwt',response.data.token)

              if (localStorage.getItem('jwt') != null){
                this.$emit('loggedIn')
                if(this.$route.params.nextUrl != null){
                  this.$router.push(this.$route.params.nextUrl)
                }
                else {
                  if(is_admin== 1){
                    this.$router.push('admin')
                  }
                  else {
                    this.$router.push('dashboard')
                  }
                }
              }
            })
            .catch(error => {
              console.error(error.response);
            });
      }
    };

    return {
      email,
      password,
      handleSubmit
    };
  }
};
</script>

<template>
  <div class="login-form">
    <h4>Login</h4>
    <form>
      <div class="form-group">
        <label for="email">E-Mail Address</label>
        <input id="email" type="email" v-model="email" required autofocus>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" type="password" v-model="password" required>
      </div>
      <div class="form-group">
        <button type="submit" @click="handleSubmit">Sign In</button>
      </div>
    </form>
  </div>
</template>

<style scoped>
.login-form {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f9f9f9;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  font-weight: bold;
}

input[type="email"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}

button {
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: #fff;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}
</style>