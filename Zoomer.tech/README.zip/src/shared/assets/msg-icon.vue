<script>
export default {
  name: "msgIcon"
}
</script>

<template>
  <div>
  <img src="../assets/msg.svg" alt="message icon" style="width:24px; height:24px;">
  </div>
</template>

<style>

</style>