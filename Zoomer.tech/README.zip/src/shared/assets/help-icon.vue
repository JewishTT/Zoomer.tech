<script>
export default {
  name: "helpIcon"
}
</script>

<template>
  <div>
    <img src="../assets/help.svg" alt="message icon" style="width:24px; height:24px;">
  </div>
</template>

<style>

</style>